function parseBookmarkResponse(tweetData) {
  const { rest_id, core, legacy, note_tweet } = tweetData?.content?.itemContent?.tweet_results?.result ?? {};
  const images = (legacy?.entities?.media ?? []).map((x) => x?.media_url_https);
  const screen_name = core?.user_results?.result?.legacy?.screen_name;
  const url = `https://twitter.com/${screen_name}/status/${rest_id}`;
  const id = rest_id;
  const nickname = core?.user_results?.result?.legacy?.name ?? "no nickname";
  const uniqueUrls = {};
  const urls = [];
  (legacy?.entities?.urls ?? []).forEach((x) => {
    if (!uniqueUrls.hasOwnProperty(x.display_url)) {
      uniqueUrls[x.display_url] = true;
      urls.push({ label: x.display_url, value: x.url });
    }
  });
  return {
    id,
    url,
    rest_id,
    nickname,
    screen_name,
    full_text: note_tweet?.note_tweet_results?.result?.text ?? legacy?.full_text,
    images,
    urls
  };
}
function beautifyLogseqText(text, urls) {
  if (!text) {
    return "";
  }
  let str1 = text.replace(/\n\n/g, "\r\n").replace(/#/g, "");
  if (urls.length > 0) {
    console.log("str1 before:", str1, urls);
    urls.forEach((item) => {
      const { label, value } = item;
      const markdownUrl = `[${label}](${value})`;
      const regex = new RegExp(value, "g");
      str1 = str1.replace(regex, () => markdownUrl);
    });
    console.log("str1 after:", str1, urls);
  }
  const entities = {
    "&lt;": "<",
    "&gt;": ">",
    "&amp;": "&",
    "&quot;": '"',
    "&apos;": "'",
    "&cent;": "¢",
    "&pound;": "£",
    "&yen;": "¥",
    "&euro;": "€",
    "&copy;": "©",
    "&reg;": "®",
    "&trade;": "™",
    "&nbsp;": " ",
    "&iexcl;": "¡",
    "&curren;": "¤",
    "&brvbar;": "¦",
    "&sect;": "§",
    "&uml;": "¨",
    "&ordf;": "ª",
    "&laquo;": "«",
    "&not;": "¬",
    "&shy;": "­",
    "&macr;": "¯",
    "&deg;": "°",
    "&plusmn;": "±",
    "&sup2;": "²",
    "&sup3;": "³",
    "&acute;": "´",
    "&micro;": "µ",
    "&para;": "¶",
    "&middot;": "·",
    "&cedil;": "¸",
    "&sup1;": "¹",
    "&ordm;": "º",
    "&raquo;": "»",
    "&frac14;": "¼",
    "&frac12;": "½",
    "&frac34;": "¾",
    "&iquest;": "¿",
    "&times;": "×",
    "&divide;": "÷"
    // ...可以继续添加更多
  };
  str1 = str1.replace(/&[a-zA-Z]+;/g, (match) => entities[match] || match);
  return str1;
}
function beautifyObsidianText(text, urls) {
  if (!text) {
    return "";
  }
  let str1 = text;
  if (urls.length > 0) {
    urls.forEach((item) => {
      const { label, value } = item;
      const markdownUrl = `[${label}](${value})`;
      const regex = new RegExp(value, "g");
      str1 = str1.replace(regex, () => markdownUrl);
    });
    console.log("str1 after:", str1, urls);
  }
  const entities = {
    "&lt;": "<",
    "&gt;": ">",
    "&amp;": "&",
    "&quot;": '"',
    "&apos;": "'",
    "&cent;": "¢",
    "&pound;": "£",
    "&yen;": "¥",
    "&euro;": "€",
    "&copy;": "©",
    "&reg;": "®",
    "&trade;": "™",
    "&nbsp;": " ",
    "&iexcl;": "¡",
    "&curren;": "¤",
    "&brvbar;": "¦",
    "&sect;": "§",
    "&uml;": "¨",
    "&ordf;": "ª",
    "&laquo;": "«",
    "&not;": "¬",
    "&shy;": "­",
    "&macr;": "¯",
    "&deg;": "°",
    "&plusmn;": "±",
    "&sup2;": "²",
    "&sup3;": "³",
    "&acute;": "´",
    "&micro;": "µ",
    "&para;": "¶",
    "&middot;": "·",
    "&cedil;": "¸",
    "&sup1;": "¹",
    "&ordm;": "º",
    "&raquo;": "»",
    "&frac14;": "¼",
    "&frac12;": "½",
    "&frac34;": "¾",
    "&iquest;": "¿",
    "&times;": "×",
    "&divide;": "÷"
    // ...可以继续添加更多
  };
  str1 = str1.replace(/&[a-zA-Z]+;/g, (match) => entities[match] || match);
  return str1;
}

export { beautifyObsidianText as a, beautifyLogseqText as b, parseBookmarkResponse as p };
