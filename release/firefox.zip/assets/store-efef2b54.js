import { d as TASK_TWITTER_BOOKMARKS_SCROLL_FOR_COLLECTION, T as TWITTER_BOOKMARKS_XHR_HIJACK, K as KEY_TWITTER_BOOKMARKS, h as KEY_SYNCED_TWITTER_BOOKMARKS_ID_LIST } from './twitter-44461355.js';

let count = 0;
let tryTime = 0;
function scroll() {
  const value = localStorage.getItem(TASK_TWITTER_BOOKMARKS_SCROLL_FOR_COLLECTION);
  if (value !== "init") {
    console.log("用户主动终止滚动");
    return false;
  }
  console.log("scroll before", count);
  window.scrollBy(0, 2e3);
  count++;
  var scrollTop = window.scrollY || document.documentElement.scrollTop;
  if (scrollTop + window.innerHeight >= document.body.scrollHeight) {
    if (tryTime >= 3) {
      console.log("已经滚动到页面底部了！");
      return false;
    } else {
      tryTime++;
    }
  } else {
    tryTime = 0;
  }
  return true;
}
function reset() {
  count = 0;
}
function scrollUntilLastBookmark() {
  const scrollInterval = setInterval(function() {
    const hasNext = scroll();
    if (!hasNext) {
      clearInterval(scrollInterval);
      localStorage.removeItem(TWITTER_BOOKMARKS_XHR_HIJACK);
      localStorage.removeItem(TASK_TWITTER_BOOKMARKS_SCROLL_FOR_COLLECTION);
      reset();
    }
  }, 1e3);
}
function collectTwitterBookmarks() {
  localStorage.setItem(TASK_TWITTER_BOOKMARKS_SCROLL_FOR_COLLECTION, "init");
  if (window.location.pathname !== "/i/bookmarks") {
    location.href = "/i/bookmarks";
  } else {
    scrollUntilLastBookmark();
  }
}

class LocalStorageStore {
  storeKey;
  constructor(storeKey) {
    this.storeKey = storeKey;
  }
  // 创建或更新记录
  upsert(data, fn) {
    const currentData = this.load();
    if (currentData == null) {
      this.save(data, fn);
    } else {
      this.insert(data, fn);
    }
  }
  load() {
    const data = localStorage.getItem(this.storeKey);
    return data ? JSON.parse(data) : null;
  }
  // 删除数据
  delete() {
    localStorage.removeItem(this.storeKey);
  }
  // 创建或更新数据
  save(data, fn) {
    localStorage.setItem(this.storeKey, JSON.stringify(data));
    fn?.({
      length: data.length
    });
  }
  // 读取数据
  // 去重更新数据
  insert(data, fn) {
    const currentData = this.load();
    let list = [];
    if (Array.isArray(currentData)) {
      const savedList = currentData.map((item) => item.id);
      list = data.filter((item) => item.id && !savedList.includes(item.id));
    }
    const oldList = currentData ?? [];
    this.save([...oldList, ...list], fn);
  }
}
const bookmarksStore = new LocalStorageStore(KEY_TWITTER_BOOKMARKS);
const syncedBookmarksStore = new LocalStorageStore(KEY_SYNCED_TWITTER_BOOKMARKS_ID_LIST);

export { scrollUntilLastBookmark as a, bookmarksStore as b, collectTwitterBookmarks as c, syncedBookmarksStore as s };
