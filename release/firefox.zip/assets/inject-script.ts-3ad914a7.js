import { b as bookmarksStore, a as scrollUntilLastBookmark } from './store-efef2b54.js';
import { T as TWITTER_BOOKMARKS_XHR_HIJACK, d as TASK_TWITTER_BOOKMARKS_SCROLL_FOR_COLLECTION } from './twitter-44461355.js';
import { p as parseBookmarkResponse } from './bookmark-ed8bd426.js';

function hookXHR(options) {
  const send = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.send = function() {
    this.addEventListener("readystatechange", () => {
      if (this.readyState === 4) {
        const r = options.after(this);
        if (!r) {
          return;
        }
        Object.defineProperty(this, "responseText", {
          value: r,
          writable: true
        });
        Object.defineProperty(this, "response", {
          value: r,
          writable: true
        });
      }
    });
    return send.apply(this, arguments);
  };
}
function filterEntries(list) {
  return list.filter((item) => !item.entryId.includes("cursor"));
}
async function hijackXHR() {
  hookXHR({
    after(xhr) {
      const isHijack = localStorage.getItem(TWITTER_BOOKMARKS_XHR_HIJACK);
      if (!isHijack)
        return;
      if (/https:\/\/twitter.com\/i\/api\/graphql\/.*\/Bookmarks/.test(xhr.responseURL)) {
        if (xhr.responseType === "" || xhr.responseType === "text") {
          const response = JSON.parse(xhr.responseText);
          const entries = filterEntries(
            response?.data?.bookmark_timeline_v2?.timeline?.instructions?.[0]?.entries ?? []
          );
          const parsedList = entries.map(parseBookmarkResponse);
          bookmarksStore.upsert(parsedList, (obj) => {
            console.log("upsert callback", obj.length);
          });
        }
      }
    }
  });
}

function twitterScroll() {
  window.onload = function() {
    const value = localStorage.getItem(TASK_TWITTER_BOOKMARKS_SCROLL_FOR_COLLECTION);
    if (value === "init") {
      scrollUntilLastBookmark();
    }
  };
}

hijackXHR();
twitterScroll();
