import { B as Browser } from './browser-polyfill-766451ca.js';
import { T as TWITTER_BOOKMARKS_XHR_HIJACK, M as MESSAGE_ORIGIN_BACKGROUND, a as MESSAGE_COLLECT_TWEETS_BOOKMARKS, b as MESSAGE_GET_PHASE_SPECIFIC_RAW_DATA, c as MESSAGE_PAUSE_TWITTER_BOOKMARKS_COLLECTION, d as TASK_TWITTER_BOOKMARKS_SCROLL_FOR_COLLECTION } from './twitter-44461355.js';
import { b as bookmarksStore, s as syncedBookmarksStore, c as collectTwitterBookmarks } from './store-efef2b54.js';

const injectScript = "/assets/inject-script.ts-3ad914a7.js";

const getUnsyncedTwitterBookmarks = (cb) => {
  const rawList = bookmarksStore.load();
  const syncedList = syncedBookmarksStore.load() ?? [];
  const list = rawList?.filter((item) => !syncedList.includes(item.id));
  cb({ data: list });
};

(function insertScript() {
  const script = document.createElement("script");
  script.src = Browser.runtime.getURL(injectScript);
  script.type = "module";
  document.head.prepend(script);
})();
(function switchOnHijack() {
  localStorage.setItem(TWITTER_BOOKMARKS_XHR_HIJACK, "1");
})();
Browser.runtime.onMessage.addListener(function(message, sender, sendResponse) {
  if (message?.from === MESSAGE_ORIGIN_BACKGROUND) {
    if (message?.type === MESSAGE_COLLECT_TWEETS_BOOKMARKS) {
      collectTwitterBookmarks();
    }
    if (message?.type === MESSAGE_GET_PHASE_SPECIFIC_RAW_DATA) {
      getUnsyncedTwitterBookmarks(sendResponse);
    }
    if (message?.type === MESSAGE_PAUSE_TWITTER_BOOKMARKS_COLLECTION) {
      localStorage.setItem(TASK_TWITTER_BOOKMARKS_SCROLL_FOR_COLLECTION, "pause");
    }
  }
  sendResponse();
});
function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
(async () => {
  let lastCount = 0;
  while (true) {
    await delay(3e3);
    const count = (bookmarksStore.load() ?? []).length;
    try {
      if (lastCount !== count) {
        await Browser.storage.local.set({ count });
        lastCount = count;
      }
    } catch (e) {
      console.log("error in content script:", e);
    }
  }
})();
