import { r as reactExports, j as jsxRuntimeExports, B as Button, P as PlayIcon, N as NoteSyncTarget, g as getUserConfig, G as GearIcon, Q as QuestionIcon, c as client, R as React } from './button-b5112c3e.js';
import { B as Browser } from './browser-polyfill-766451ca.js';
import { g as MESSAGE_ORIGIN_POPUP, c as MESSAGE_PAUSE_TWITTER_BOOKMARKS_COLLECTION, e as MESSAGE_SYNC_TO_LOGSEQ, a as MESSAGE_COLLECT_TWEETS_BOOKMARKS, f as MESSAGE_SYNC_TO_OBSIDIAN } from './twitter-44461355.js';

const logo = ""+new URL('logo-24b4b924.png', import.meta.url).href+"";

/**
 * @license lucide-react v0.372.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */

var defaultAttributes = {
  xmlns: "http://www.w3.org/2000/svg",
  width: 24,
  height: 24,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 2,
  strokeLinecap: "round",
  strokeLinejoin: "round"
};

/**
 * @license lucide-react v0.372.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */

const toKebabCase = (string) => string.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase();

/**
 * @license lucide-react v0.372.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const createLucideIcon = (iconName, iconNode) => {
  const Component = reactExports.forwardRef(
    ({
      color = "currentColor",
      size = 24,
      strokeWidth = 2,
      absoluteStrokeWidth,
      className = "",
      children,
      ...rest
    }, ref) => {
      return reactExports.createElement(
        "svg",
        {
          ref,
          ...defaultAttributes,
          width: size,
          height: size,
          stroke: color,
          strokeWidth: absoluteStrokeWidth ? Number(strokeWidth) * 24 / Number(size) : strokeWidth,
          className: ["lucide", `lucide-${toKebabCase(iconName)}`, className].join(" "),
          ...rest
        },
        [
          ...iconNode.map(([tag, attrs]) => reactExports.createElement(tag, attrs)),
          ...Array.isArray(children) ? children : [children]
        ]
      );
    }
  );
  Component.displayName = `${iconName}`;
  return Component;
};

/**
 * @license lucide-react v0.372.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const Pause = createLucideIcon("Pause", [
  ["rect", { x: "14", y: "4", width: "4", height: "16", rx: "1", key: "zuxfzm" }],
  ["rect", { x: "6", y: "4", width: "4", height: "16", rx: "1", key: "1okwgv" }]
]);

function Syncwise({ count, target }) {
  const handlePauseCollect = () => {
    Browser.runtime.sendMessage({
      from: MESSAGE_ORIGIN_POPUP,
      type: MESSAGE_PAUSE_TWITTER_BOOKMARKS_COLLECTION
    });
  };
  const handleSync = () => {
    Browser.runtime.sendMessage({
      from: MESSAGE_ORIGIN_POPUP,
      type: MESSAGE_SYNC_TO_LOGSEQ
    });
  };
  const handleCollect = () => {
    Browser.runtime.sendMessage({
      from: MESSAGE_ORIGIN_POPUP,
      type: MESSAGE_COLLECT_TWEETS_BOOKMARKS
    });
  };
  const handleSyncToObsidian = () => {
    Browser.runtime.sendMessage({
      from: MESSAGE_ORIGIN_POPUP,
      type: MESSAGE_SYNC_TO_OBSIDIAN
    });
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center space-x-2", children: [
      "已收集",
      count,
      "条书签🔖"
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { onClick: handleCollect, placeholder: "", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(PlayIcon, { size: 16 }),
      " 开始收集"
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { onClick: handlePauseCollect, placeholder: "", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Pause, { className: "text-sm", size: 18 }),
      " 暂停收集"
    ] }),
    target === NoteSyncTarget.Logseq && /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { onClick: handleSync, placeholder: "", children: "同步到 Logseq" }),
    target === NoteSyncTarget.Obsidian && /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { onClick: handleSyncToObsidian, placeholder: "", children: "同步到 Obsidian" })
  ] });
}

function PopupPage() {
  const [target, setTarget] = reactExports.useState(null);
  const [count, setCount] = reactExports.useState(0);
  reactExports.useEffect(() => {
    getUserConfig().then((config) => {
      setTarget(config.target);
    });
  }, []);
  reactExports.useEffect(() => {
    (async () => {
      const obj = await Browser.storage.local.get("count");
      setCount(obj.count || 0);
    })();
    Browser.storage.local.onChanged.addListener((v) => {
      if (v.count.newValue !== v.count.oldValue) {
        setCount(v.count.newValue);
      }
    });
  }, []);
  const openOptionsPage = reactExports.useCallback(() => {
    Browser.runtime.sendMessage({ type: "OPEN_OPTIONS_PAGE" });
  }, []);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-[400px] space-y-4 p-4 flex flex-col h-full bg-white text-black", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-2 flex flex-row items-center px-1", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: logo, className: "w-5 h-5 rounded-sm" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-semibold m-0 ml-1", children: "Syncwise" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grow" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "cursor-pointer leading-[0]", onClick: openOptionsPage, children: /* @__PURE__ */ jsxRuntimeExports.jsx(GearIcon, { size: 16 }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("a", { href: "https://github.com/slarkvan/syncwise", target: "_blank", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(QuestionIcon, { size: 16 }),
      " 配置文档"
    ] }) }),
    target ? /* @__PURE__ */ jsxRuntimeExports.jsx(Syncwise, { count, target }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { children: "你还未选择同步到哪个笔记" })
  ] });
}

function App() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(PopupPage, {});
}

const index = '';

client.createRoot(document.getElementById("root")).render(
  /* @__PURE__ */ jsxRuntimeExports.jsx(React.StrictMode, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(App, {}) })
);
