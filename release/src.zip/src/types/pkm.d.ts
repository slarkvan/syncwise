export enum NoteSyncTarget {
    Logseq = 'logseq',
    Obsidian = 'obsidian',
}

export enum NoteSyncLocationType {
    Journal = 'Journal',
    CustomPage = 'customPage',
}
