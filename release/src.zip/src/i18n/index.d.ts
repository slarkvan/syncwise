export type TranslateType = {
    "example": {
        value: "example"
        params: [key: "example"]
    }
};