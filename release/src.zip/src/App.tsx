import PopupPage from '@/scope/popup'

export function App() {
    return <PopupPage />
}
